# Rainbow visual review

## Start here

This nine-picture Android batch contains the exact approved artwork and four full-size Claudia/candidate pairs for Screen 08. The master image ZIP includes the other viewpoints.

The five folders are Screen_04, Screen_05, Screen_06, Screen_07 and Screen_08. Each number refers to a playable stage in the existing Rainbow Android game. Benny is the pink swimmer in the purple-and-white beanie.

For an independent review, inspect the artwork, retained ride and candidate at the same stage position. Write down what you see before checking the supplied observations.

1. In the image package, open the full-screen SCREEN##_APPROVED.jpg. All five are exact copies of the original approved files. Screen 05 also has a separate original water-detail reference.

2. In Current/, compare SCREEN##_CLAUDIA_OPENING and SCREEN##_CODEX_CANDIDATE_OPENING. Continue with the same FORWARD, HARD_LEFT, HARD_RIGHT, MIDDLE, DEEP, stage-specific feature, FINAL_APPROACH and STAGE_TRANSITION filenames. The FILE_INDEX.csv identifies every source and any identical shared picture.

3. In the video package, open SCREEN##_CLAUDIA_RETAINED_ENTRANCE_TO_EXIT.mp4 and SCREEN##_CODEX_CANDIDATE_ENTRANCE_TO_EXIT.mp4 directly inside the matching screen folder. These are the ten primary clips. Compare the same timestamp in each.

4. On Android, attach the two master ZIPs in the same conversation when your app accepts them. If the app cannot open a ZIP, extract one small stage batch in your Files app and attach its original artwork and matched screenshots. The download page also offers the individual MP4s. If video playback is unavailable in chat, the named stills and frame logs show the important positions.

### Suggested message for ChatGPT

Review the five approved Rainbow screens against Claudia’s retained Three.js gameplay and each labeled Codex candidate. Read README_FIRST.md and open the actual media. For each stage, name the largest scenery mismatches at the approved opening and during forward travel, turns, drops and the handoff. Cite a screenshot filename or a video timestamp for each finding. Say which candidates help, which make things worse and what to test next. Measure the approved viewpoint only. For unseen views, assess continuity and flag interpretation. If a file cannot be opened, identify it.

## Labels

- APPROVED identifies the owner’s original artwork. CLAUDIA RETAINED identifies the latest saved specialist configuration reproduced in the real game. Claudia_Saved includes originals recorded by Claudia, earlier rounds and the separately labeled unfinished Screen 08 glint work.

- CANDIDATE identifies a Codex experiment awaiting owner review. REJECTED identifies a test ruled out for promotion. No Codex experiment has an owner-confirmed ACCEPTED status. A diagnostic image may hide an object, show a measurement overlay, or show a Blender component on its own. Use Current/ for normal gameplay.

- The historical Screen 04 ring specialist came from its own branch. Older Screen 05 water studies and earlier Screen 07 bank and paddle trials have their own labels. A prior default capture in a historical study belongs to that study’s source checkpoint.

## Screens and verified GitHub checkpoints

### Screen 08 · Final Spin Chamber

Large metallic chamber, door, gold ring, perforated platform, folded purple towel, four gold-banded spouts and winding river.

The candidate makes the foreground bank follow the river while the chamber objects hold position. Cyan still smears at +3 and the near pink bank can fill much of the lower frame.

Claudia’s retained branch is `claude/rainbow-s08-scenery-c17` at `3c0fa97090afb2c0fca41898774db7247e23e522`. [GitHub checkpoint](https://github.com/josiahscalia5-dev/rainbow-/commit/3c0fa97090afb2c0fca41898774db7247e23e522)

The candidate is on `codex/s08-curved-chamber-current`. Its source commit is `4e68fa16d3e3cdf3350f0c3f561cbe705375a55e`. Its saved evidence commit is `19970fa9de964db8836814a57c773a0f45ffde29`. [GitHub evidence](https://github.com/josiahscalia5-dev/rainbow-/commit/19970fa9de964db8836814a57c773a0f45ffde29)

Opening RGB agreement was 84.0857% for Claudia and 84.0857% for the candidate. Pixelmatch found 197,021 and 197,021 mismatches respectively.

## Video timestamps

Times are measured from the first frame in each primary MP4. Each window was located in the 12 fps ride log by along-course position and checked against the saved footage. A hard-steer still uses an independent input at the named position. The continuous ride uses its recorded steering there.

### 08 · Final Spin Chamber

- **0:00.50–0:00.83**, frames 6–10. Inspect the broad cyan smear just downstream of the opening.

- **0:01.00–0:01.50**, frames 12–18. Follow the foreground magenta turn while checking the door, towel, platform and four spouts for stable placement.

- **0:01.58–0:01.75**, frames 19–21. First visible frame in Screen 09. Compare continuity with the outgoing stage.

### Supporting recordings

Claudia’s separate 432 × 768 specialist clips are 3.58 seconds long at 24 fps. On 04, inspect the gold band at about 0–1 seconds and the stage change around 2 seconds. On 06, inspect the ring stack and foam over roughly 1–2.5 seconds. On 07, inspect the white banks and river lip at about 1–3 seconds. These clips have their own steering, score and wall bumps. The 07 historical angular-material test has two 3.25-second steering segments. Watch their paddle and banks around 1–2.5 seconds. Their endpoints are the recorded segment endpoints.

## Camera, gameplay and measurements

The photographed opening is the single exact design viewpoint for each stage. Native current stills are 864 × 1536 pixels, DPR 1, with matched camera transform, position, steering and shader clock. Opening, entrance and the first frame of the ride are different positions. CAMERA_POSES.csv gives the actual values.

The primary clips replay the retained real Three.js renderer using the saved fixed-step ride. The CSS viewport remains 324 × 576, the drawing buffer is 648 × 1152, and the stream is H.264 at 12 fps. There are five 1/60-second game steps per recorded frame. Every frame was checked against its original ride for course position, lateral movement, steering, camera, shader clock, hearts and score. The original 324 × 576 recordings are also packaged. Higher physical pixel density changes antialiasing and texture sampling.

RGB agreement counts the whole-frame fraction with mean absolute RGB error at most 20 on a 0–255 scale. Pixelmatch 7.1.0 uses threshold 0.1 with antialias mismatches excluded. The reports measure the original source pixels, including Benny and the HUD. Full-size review JPEGs can change individual channel values. For pixel-level work use the standalone native-image ZIP parts.

Use visual judgment for unpictured moving viewpoints. The reference establishes materials, shapes and composition at its photographed viewpoint. The camera beyond that viewpoint and hidden surfaces require interpretation. An exact reference percentage for the unseen route is unavailable.

Both retained and candidate builds passed eight gameplay assertions, collected 91 coins, and advanced the full-game score from 1,330 to 2,240. All ten primary stage rides retained five hearts, and all five saved across-transition images matched their baseline exactly. Screen 04’s ordinary full-game coin run lost one heart in both builds. A separate full-game safe route collected 91 and finished at 2,240 with five hearts in each. Screen 08’s separate full-steer collision stills cost one heart in both versions.

## Historical sources and limits

The verified lead is `ccr-bbe2b27e-oxfh1w` at `d22ec46b72146d69703d4271cd54c1c852164dff`. The separate Screen 04 ring specialist is `claude/rainbow-s04-ringtex-c17` at `0f275af1e3d4e9276e5a4016d0335a85fe055e58`.

Screen 07’s rejected Image2Blender bank and foam experiment is `codex/s07-magenta-bank-shape` at `91c51749cc11ab9e56924625d46bf8f3395aede0`. Forward travel widened the banks. Both hard turns crowded the cyan channel. Blender-only images show isolated geometry. The earlier angle-only paddle result came from a disposable in-memory test based on Claudia’s 07 commit. It has saved matched evidence and no separate GitHub implementation commit. The later fitted-paddle candidate is a different result.

The November 16 Screen 05 historical studies precede Account 17. The reference-fit report identifies the earlier water-reference study as rejected. The later fit and earlier opt-in liquid result have no recorded owner acceptance. The glow study’s CHOSEN label means selected during that tuning run. Its alternative settings are diagnostics. The FILE_INDEX.csv gives the individual captured source paths.

- `codex/screen05-water-experiment-20261116` at `d493cc360cf631d5bfa5adbbba3e08e91e67e1df`. [GitHub revision](https://github.com/josiahscalia5-dev/rainbow-/commit/d493cc360cf631d5bfa5adbbba3e08e91e67e1df)

- `codex/screen05-water-hfb8p0-20261116` at `4abf5483949de3893ee4d96d0c1f6e0ff9e86a89`. [GitHub revision](https://github.com/josiahscalia5-dev/rainbow-/commit/4abf5483949de3893ee4d96d0c1f6e0ff9e86a89)

- `codex/screen05-approved-water-study-20261116` at `576526edf6e7e964c373c6e5d9c1075b55f8b42a`. [GitHub revision](https://github.com/josiahscalia5-dev/rainbow-/commit/576526edf6e7e964c373c6e5d9c1075b55f8b42a)

- `codex/screen05-reference-fit-20261116` at `74e3fde6d1ab5a52fe6661153ba818a3b12fc65d`. [GitHub revision](https://github.com/josiahscalia5-dev/rainbow-/commit/74e3fde6d1ab5a52fe6661153ba818a3b12fc65d)

The frame at +20 from Screen 08’s approved opening lands outside Stage 08. Use its last in-stage and outgoing frames. Each stage was recorded from its own verified specialist checkpoint. Its outgoing frame shows the destination scene available on that branch. There is no merged five-candidate build in this evidence.

The 12 fps video sampling can miss a flash shorter than a sampled interval. GPU and gameplay checks were run in desktop Chromium with SwiftShader. Sustained performance on a physical Android phone remains unmeasured. The packages cover playable Screens 04–08. Google Flow video scenes, credentials, recovery backups, development dependencies and model binaries are outside the visual collection.

## Measurement files

Each screen’s Reports/ directory contains original opening metrics, full-stage motion measurements, camera and ride CSVs, source revisions and gameplay assertions. Relevant rejected-opening and historical fit measurements appear under the same Reports/ folder. SHA256SUMS.txt covers the files actually contained in each ZIP.
